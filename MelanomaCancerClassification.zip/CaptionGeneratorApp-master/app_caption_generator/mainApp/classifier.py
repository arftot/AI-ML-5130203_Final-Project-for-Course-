import torch
import torchvision.transforms as T
from PIL import Image
import logging
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)

class ConvolutionalNet(nn.Module):

  def __init__(self, num_classes=10):
    super(ConvolutionalNet, self).__init__()
    # convolutional layers
    self.conv1 = nn.Conv2d(in_channels=3, out_channels=32, kernel_size=(3, 3), padding=1, stride=1)
    self.bn1 = nn.BatchNorm2d(32)
    self.conv2 = nn.Conv2d(in_channels=32, out_channels=32, kernel_size=(3, 3), padding=1, stride=1)
    self.bn2 = nn.BatchNorm2d(32)
    self.conv3 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=(3, 3), padding=1, stride=1)
    self.bn3 = nn.BatchNorm2d(64)
    self.conv4 = nn.Conv2d(in_channels=64, out_channels=64, kernel_size=(3, 3), padding=1, stride=1)
    self.bn4 = nn.BatchNorm2d(64)
    self.conv5 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=(3, 3), padding=1, stride=1)
    self.bn5 = nn.BatchNorm2d(128)
    self.conv6 = nn.Conv2d(in_channels=128, out_channels=128, kernel_size=(3, 3), padding=1, stride=1)
    self.bn6 = nn.BatchNorm2d(128)
    # max pooling layers
    self.maxpool = nn.MaxPool2d(kernel_size=(2, 2))

    # fully-connected layers
    self.fc1 = nn.Linear(in_features = 2048, out_features = 512)
    self.fc2 = nn.Linear(in_features = 512, out_features = 128)
    self.fc3 = nn.Linear(in_features = 128, out_features = num_classes)
    self.bn_fc1 = nn.BatchNorm1d(512)
    self.bn_fc2 = nn.BatchNorm1d(128)

  def forward(self, x):
    # convolutional
    out = F.relu(self.bn1(self.conv1(x)))
    out = F.relu(self.bn2(self.conv2(out)))
    out = self.maxpool(out)
    out = F.relu(self.bn3(self.conv3(out)))
    out = F.relu(self.bn4(self.conv4(out)))
    out = self.maxpool(out)
    out = F.relu(self.bn5(self.conv5(out)))
    out = F.relu(self.bn6(self.conv6(out)))
    out = self.maxpool(out)

    # flattened
    out = out.view(out.size(0), -1)   # batch-size dim maintain
    # fully-connected layers
    out = F.relu(self.bn_fc1(self.fc1(out)))
    out = F.relu(self.bn_fc2(self.fc2(out)))
    out = self.fc3(out)

    return out

  def get_total_params(self):
    return sum(p.numel() for p in self.parameters() if p.requires_grad)
  
class ImageClassifier:
    def __init__(self) -> None:
        logger.info("Start to load model.")
        model_path = '/Users/kristinamarchenko/Downloads/CaptionGeneratorApp-master/app_caption_generator/mainApp/cnn_v035.pt'

        # Initialize the model first
        self.model = ConvolutionalNet(num_classes=10)  # Ensure num_classes matches the model's output
        # Load the model's weights
        self.model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu'), weights_only=True))
        
        # Set the model to evaluation mode
        self.model.eval()

        self.device = "cpu"
        self.model.to(self.device)
        logger.info("Model loaded successfully.")

        # Transformations
        self.transform = T.Compose([
            T.Resize((32, 32)),  # Resize image
            T.ToTensor(),  # Convert image to tensor
            T.Normalize(mean = (0.5, 0.5, 0.5), std = (0.5, 0.5, 0.5))  # Normalize
        ])
    
    def predict(self, image_path):
        logger.info("Start to predict.")
        # Open the image
        image = Image.open(image_path)

        # Apply transformations
        image = self.transform(image).unsqueeze(0)  # Add batch dimension
        image = image.to(self.device)

        # Get predictions from the model
        with torch.no_grad():  # Disable gradient calculations
            outputs = self.model(image)
        
        # Get the predicted class
        _, predicted_class = torch.max(outputs, 1)
        class_labels = {0: "Benign", 1: "Malignant"}  
        return class_labels.get(predicted_class.item(), "Unknown")

# Initialize the classifier and make a prediction
classifier = ImageClassifier()
#prediction = classifier.predict('/Users/kristinamarchenko/Downloads/CaptionGeneratorApp-master/app_caption_generator/static/storage/6299.jpg')

# Output the prediction
#print(f"Prediction: {prediction}")